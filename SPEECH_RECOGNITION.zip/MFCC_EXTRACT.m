
soundList = {'yes', 'no', 'hello', 'goodbye', 'please', 'thank you', 'excuse me', 'help', 'stop', 'go', 'left', 'right', 'up', 'down', 'begin-', 'end', 'open', 'closed', 'on', 'off'};
filePattern = fullfile('_aug', '*.wav'); 
audioFiles = dir(filePattern);
numFiles = length(audioFiles);
fileList = cell(numFiles, 1);


features = [];
labels = [];

numVoices = 1000;  
numRepetitions = 5;  
numTrainVoices = 900; 
numTestVoices = numVoices - numTrainVoices;

for i = 1:numel(soundList)
    for j = 1:numRepetitions
        for k = 1:10
            
            filename = fullfile( ['rec_', soundList{i}, '_', num2str(j), '_aug', num2str(k), '.wav']);

           
            [audioData, fs] = audioread(filename);

           
            if size(audioData, 2) > 1
                audioData = mean(audioData, 2);
            end
            if(size(audioData,1) > 88200)
                audioData = audioData(1:88200);
            end

            
            mfccFeature = computeMFCC(audioData, fs, 13);
            features = [features; mfccFeature];

  
label = repmat({soundList{i}}, 1, 1); 
  labels = [labels; label]; 

        end
    end
end

rng(1);  
shuffledIndices = randperm(numVoices);
shuffledFeatures = features(shuffledIndices, :);
shuffledLabels = labels(shuffledIndices, :);


trainFeatures = shuffledFeatures(1:numTrainVoices, :);
trainLabels = shuffledLabels(1:numTrainVoices, :);
testFeatures = shuffledFeatures(numTrainVoices+1:end, :);
testLabels = shuffledLabels(numTrainVoices+1:end, :);

disp('Features and labels are ready for use!')
disp('Training set:')
disp(trainFeatures);
disp(trainLabels);
disp('Testing set:')
disp(testFeatures);
disp(testLabels);
disp('Features:')
disp(features);
disp('Labels:')
disp(labels);


function mfccs = computeMFCC(signal, fs, numCoeffs)
    frameLength = round(0.025 * fs);  
    frameStep = round(0.01 * fs);     
    signalLength = length(signal);

    numFrames = 1 + floor((signalLength - frameLength) / frameStep);

    hammingWindow = hamming(frameLength);

    mfccs = zeros(numFrames, numCoeffs);

    for i = 1:numFrames
        startIdx = (i - 1) * frameStep + 1;
        endIdx = startIdx + frameLength - 1;

        if endIdx > signalLength
            break;
        end

        frame = signal(startIdx:endIdx) .* hammingWindow;

        frameFFT = fft(frame, 2*frameLength); 
        magFrame = abs(frameFFT(1:frameLength/2+1));

        melSpectrum = melFilter(magFrame, fs);

        logMelSpectrum = log(melSpectrum + 1e-10);

        mfcc = dct(logMelSpectrum);

        mfccs(i, :) = mfcc(1:numCoeffs);
    end
end


function melSpectrum = melFilter(spectrum, fs)
      numFilters = 26;
    NFFT = length(spectrum) * 2;

    melPoints = linspace(0, hz2mel(fs / 2), numFilters + 2);
    hzPoints = mel2hz(melPoints);
    bin = floor((NFFT + 1) * hzPoints / fs);

    bin(bin < 1) = 1;
    bin(bin > NFFT / 2) = NFFT / 2;

    melFilterBank = zeros(numFilters, floor(NFFT / 2));

    for i = 1:numFilters
        melFilterBank(i, bin(i):bin(i+1)) = linspace(0, 1, bin(i+1) - bin(i) + 1);
        melFilterBank(i, bin(i+1):bin(i+2)) = linspace(1, 0, bin(i+2) - bin(i+1) + 1);
    end

    melSpectrum = melFilterBank * spectrum;
end


function mel = hz2mel(hz)
    mel = 2595 * log10(1 + hz / 700);
end


function hz = mel2hz(mel)
 hz = 700 * (10.^(mel / 2595) - 1);
end


