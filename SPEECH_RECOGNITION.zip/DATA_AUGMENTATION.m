
soundList = {'yes', 'no', 'hello', 'goodbye', 'please', 'thank you', 'excuse me', 'help', 'stop', 'go', 'left', 'right', 'up', 'down', 'begin-', 'end', 'open', 'closed', 'on', 'off'};
numRepetitions = 5;

speedFactors = [0.8, 1.2]; 
noiseLevels = [0.01, 0.05]; 
timeShifts = [0.1, 0.2]; 

for i = 1:numel(soundList)
    for j = 1:numRepetitions
       
        filename = ['rec_', soundList{i}, '_rep', num2str(j), '.wav'];
        [audioData, fs] = audioread(filename);
        
      
        for k = 1:10  
            
            speedFactor = speedFactors(randi(length(speedFactors)));
            augmentedData = changeSpeed(audioData, fs, speedFactor);
           
            noiseLevel = noiseLevels(randi(length(noiseLevels)));
            augmentedData = addNoise(augmentedData, noiseLevel);
            
        
            timeShift = timeShifts(randi(length(timeShifts)));
            augmentedData = shiftTime(augmentedData, fs, timeShift);
            
            augmentedFilename = ['rec_',soundList{i},'_' ,num2str(j), '_aug', num2str(k), '.wav'];
            audiowrite(augmentedFilename, augmentedData, fs);
        end
    end
end


function augmentedData = changeSpeed(audioData, fs, speedFactor)
    augmentedData = resample(audioData, speedFactor*fs, fs);
end


function augmentedData = addNoise(audioData, noiseLevel)
    noise = noiseLevel * randn(size(audioData));
    augmentedData = audioData + noise;
end


function augmentedData = shiftTime(audioData, fs, timeShift)
    timeShiftSamples = round(timeShift * fs);
    if timeShiftSamples > 0
        augmentedData = [audioData(timeShiftSamples+1:end); zeros(timeShiftSamples, 1)];
    else
        augmentedData = [zeros(-timeShiftSamples, 1); audioData(1:end+timeShiftSamples)];
    end
end