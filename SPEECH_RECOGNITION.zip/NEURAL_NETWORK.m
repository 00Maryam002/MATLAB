
inputSize = size(trainFeatures, 2); 

numClasses = numel(soundList);


layers = [
    imageInputLayer([1 1 inputSize])
    fullyConnectedLayer(128)
    reluLayer
    fullyConnectedLayer(128)
    reluLayer
    fullyConnectedLayer(numClasses)
    softmaxLayer
    classificationLayer];

options = trainingOptions('adam', ...
    'MaxEpochs', 100, ...
    'MiniBatchSize', 16, ...
    'InitialLearnRate', 1e-3, ...
    'Plots', 'training-progress');

trainLabelsCategorical = categorical(trainLabels);


trainFeaturesReshaped = reshape(trainFeatures', [1, 1, inputSize, size(trainFeatures, 1)]);
testFeaturesReshaped = reshape(testFeatures', [1, 1, inputSize, size(testFeatures, 1)]);

net = trainNetwork(trainFeaturesReshaped, trainLabelsCategorical, layers, options);

predictedLabels = classify(net, testFeaturesReshaped);

disp('Predicted Labels:');
disp(predictedLabels);
















