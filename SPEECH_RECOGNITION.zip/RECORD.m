fs = 44100;
nBits = 16;
nChannels = 1;

soundList = {'yes', 'no', 'hello', 'goodbye', 'please', 'thank you', 'excuse me', 'help', 'stop', 'go', 'left', 'right', 'up', 'down', 'begin-', 'end', 'open', 'closed', 'on', 'off'};
numRepetitions = 5;

for i = 1:numel(soundList)
    for j = 1:numRepetitions
      
        prompt = ['Speak "', soundList{i}, '", repetition ', num2str(j), '.'];
        disp(prompt);

        recObj = audiorecorder(fs, nBits, nChannels);
        recordblocking(recObj, 2);

        audioData = getaudiodata(recObj);
        filename = ['rec_', soundList{i}, '_rep', num2str(j), '.wav'];
        audiowrite(filename, audioData, fs);

        disp(['Audio recorded and saved as ', filename]);
    end
end
figure;

selectedSoundIndex = 5; 
selectedSound = soundList{selectedSoundIndex};


recObj = audiorecorder(fs, nBits, nChannels);


recordblocking(recObj, 2);


audioData = getaudiodata(recObj);
time = (0:length(audioData)-1) / fs; 
figure;
plot(time, audioData);
xlabel('Sample Number');
ylabel('Amplitude');
title(['Waveform of "', selectedSound, '"']);